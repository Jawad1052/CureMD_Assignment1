﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Project.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Courses : ControllerBase
    {
        private readonly string _connectionString;

        public Courses(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
        }

        [HttpGet]
        public IActionResult GetAllCourses()
        {
            List<Course> crs = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("ShowAllCourses", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course std = new Course();
                        std.CourseID = (int)reader["CourseID"];
                        std.CourseName = reader["CourseName"].ToString();


                        crs.Add(std);
                    }
                }
            }
            return Ok(crs);
        }
        [HttpGet("{id}")]
        public IActionResult GetCoursesByID(int id)
        {
            Course employee = new Course();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetCourseById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", id);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                       

                        employee.CourseID = (int)reader["CourseID"];
                        employee.CourseName = reader["CourseName"].ToString();
                    }
                }
            }
            return Ok(employee);
        }
        [HttpPost]
        public IActionResult AddCourse(Course cd)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    
                    command.Parameters.AddWithValue("@CourseID", cd.CourseID);
                    command.Parameters.AddWithValue("@CourseName", cd.CourseName);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok(cd);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCourse(int id, Course crs)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID",id);
                    command.Parameters.AddWithValue("@CourseName", crs.CourseName);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok(crs);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCourse(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteCourseBy", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", id);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok(id);
        }
    }
}

