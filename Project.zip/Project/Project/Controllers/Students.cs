﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Data;
using Project.Models;

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Students : ControllerBase
    {
        private readonly string _connectionString;

        public Students(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
        }

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            List<Student> employees = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("ShowStudentAll", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student std = new Student();
                       std.StudentID = (int)reader["StudentID"];
                       std.FirstName = reader["FirstName"].ToString();
                       std.LastName = reader["LastName"].ToString();
                       std.Age = (int)reader["Age"];
                       std.CourseID = (int)reader["CourseID"];

                        employees.Add(std);
                    }
                }
            }
            return Ok(employees);
        }

        [HttpGet("{id}")]
        public IActionResult GetEmployeeById(int id)
        {
            Student employee = new Student();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetStudentById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", id);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        employee.StudentID = (int)reader["StudentID"];
                        employee.FirstName = reader["FirstName"].ToString();
                        employee.LastName = reader["LastName"].ToString();
                        employee.Age = (int)reader["Age"];
                        employee.CourseID = (int)reader["CourseID"];
                    }
                }
            }
            return Ok(employee);
        }

        [HttpPost]
        public IActionResult AddEmployee(Student std)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", std.StudentID);
                    command.Parameters.AddWithValue("@FirstName", std.FirstName);
                    command.Parameters.AddWithValue("@LastName", std.LastName);
                    command.Parameters.AddWithValue("@Age", std.Age);
                    command.Parameters.AddWithValue("@CourseID", std.CourseID);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok();
        }

        [HttpPut("{id}")]
        public IActionResult UpdateEmployee(int id, Student std)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", std.StudentID);
                    command.Parameters.AddWithValue("@FirstName", std.FirstName);
                    command.Parameters.AddWithValue("@LastName", std.LastName);
                    command.Parameters.AddWithValue("@Age", std.Age);
                    command.Parameters.AddWithValue("@CourseID", std.CourseID);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok(std);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmployee(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", id);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            return Ok(id);
        }


    }
}
